Space Battle Arena Client Quick-Start for Java using VS Code
============================================================

[See Documentation](https://mikeware.github.io/SpaceBattleArena/client/vscode/index.html)

Needs **Java Extension Pack** in VS Code: `vscjava.vscode-java-pack`

Use F5 in `ExampleShip.java` file to run project.

Type `quit` in terminal after running to terminate program and cleanly disconnect from server.
